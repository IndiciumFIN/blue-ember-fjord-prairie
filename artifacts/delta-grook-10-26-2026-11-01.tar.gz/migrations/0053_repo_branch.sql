-- O commit é da branch, não do arquivo. Tirá-lo de repo_file cumpre a 2FN.

create table if not exists repo_branch (
  repo text not null references repo_source (repo),
  branch text not null,
  commit text not null,
  primary key (repo, branch)
);

do $$
begin
  if exists (
    select 1 from information_schema.columns
    where table_schema = 'public' and table_name = 'repo_file' and column_name = 'commit'
  ) then
    insert into repo_branch (repo, branch, commit)
    select repo, branch, min(commit)
    from repo_file
    group by repo, branch
    on conflict (repo, branch) do nothing;
  end if;
  if not exists (select 1 from pg_constraint where conname = 'repo_file_branch_fkey') then
    alter table repo_file
      add constraint repo_file_branch_fkey
      foreign key (repo, branch) references repo_branch (repo, branch);
  end if;
end $$;

alter table repo_file drop column if exists commit;

insert into schema_entity (name, layer_id, primary_key, purpose, links)
values ('repo_branch', 'processo', 'repo + branch', 'Ponta vista de uma branch. O commit não se repete em cada arquivo.', 'repo → repo_source.repo')
on conflict (name) do update
set primary_key = excluded.primary_key, purpose = excluded.purpose, links = excluded.links;

update schema_entity
set purpose = 'Arquivo visto numa branch. O commit fica na branch, não aqui.',
    links = 'repo + branch → repo_branch'
where name = 'repo_file';

insert into schema_column (entity, name, data_type, required, key_part, ref_entity, definition, syntax, unit)
values
  ('repo_branch', 'repo', 'texto', true, true, 'repo_source', 'Repositório desta ponta.', 'repo existente', null),
  ('repo_branch', 'branch', 'texto', true, true, null, 'Branch vista.', 'texto', null),
  ('repo_branch', 'commit', 'texto', true, false, null, 'Commit desta branch neste repositório. A branch sozinha, noutro repositório, não o determina.', 'sha', null)
on conflict (entity, name) do nothing;

delete from data_specification where entity = 'repo_file' and characteristic = 'commit';
delete from schema_column where entity = 'repo_file' and name = 'commit';

insert into schema_relation (from_entity, name, to_entity, cardinality, from_column, to_column, definition)
values
  ('repo_source', 'branches', 'repo_branch', '1:N', 'repo', 'repo', 'Um repositório tem zero ou mais branches vistas.'),
  ('repo_branch', 'arquivos', 'repo_file', '1:N', 'branch', 'branch', 'Uma branch tem zero ou mais arquivos. O arquivo também guarda o repositório.')
on conflict (from_entity, name) do nothing;

insert into data_specification (id, entity, characteristic, definition, syntax, unit, required, owner_role, source)
select 'spec-' || entity || '-' || name, entity, name, definition, syntax, unit, required, 'administrador', entity || '.' || name
from schema_column
where entity = 'repo_branch'
on conflict (id) do nothing;
